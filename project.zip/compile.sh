#!/bin/bash

########################################
############# CSCI 2951-O ##############
########################################

# Update this file with instructions on how to compile your code
python3 -m venv .env
source .env/bin/activate
pip install -r requirements.txt
